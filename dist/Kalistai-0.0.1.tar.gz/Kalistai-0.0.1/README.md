# Kalistai

## Import

! pip install https://github.com/TanguyPerennec/Kalistai
