from setuptools import find_packages, setup

setup(
    name='Kalistai',
    packages=find_packages(include=['mypythonlib']),
    version='0.0.1',
    url='https://github.com/TanguyPerennec/Kalistai',
    description='Basic function to facilitate DL',
    author='Kalistai group',
    license='MIT'
)

